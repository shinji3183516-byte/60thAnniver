"use strict";
const timelineData = [
  {
    "year": "1966",
    "era": "昭和41年",
    "title": "高岡工場スタート",
    "visual": "PLANT",
    "car": "高岡工場は、モータリゼーションを支える生産拠点として歩みを始めました。",
    "factory": "工場の歩みの起点。生産車種と工場の歴史をここから紹介します。",
    "factoryImage": "images/takaoka_1gousha.jpg",
    "society": "高度経済成長の中で、家庭に車が広がっていく時代でした。",
    "spec1": "創業期",
    "spec2": "生産開始",
    "spec3": "60年の起点",
    "image": "images/1966.jpg"
  },
  {
    "year": "1978",
    "era": "昭和53年",
    "title": "カローラ生産拡大",
    "visual": "COROLLA",
    "car": "カローラを中心に、小型で扱いやすい車づくりが広がりました。",
    "factory": "量産体制を強め、高岡工場の存在感が高まっていきました。",
    "society": "生活の中に自動車が定着し、大衆車の需要が拡大しました。",
    "spec1": "カローラ",
    "spec2": "量産",
    "spec3": "大衆車",
    "image": "images/3.jpg"
  },
  {
    "year": "1984",
    "era": "昭和59年",
    "title": "品質向上とグローバル対応",
    "visual": "QUALITY",
    "car": "カローラFXなど、使いやすさと品質を重視した車種が登場しました。",
    "factory": "品質・生産性向上に取り組み、グローバルな車づくりへつながりました。",
    "society": "省エネ志向や小型車需要が高まりました。",
    "spec1": "品質",
    "spec2": "効率化",
    "spec3": "海外支援",
    "image": "images/5.jpg"
  },
  {
    "year": "1997",
    "era": "平成9年",
    "title": "プリウス生産開始",
    "visual": "PRIUS",
    "car": "世界初の量産ハイブリッド車プリウスの生産により、環境技術の時代へ進みました。",
    "factory": "新しい技術を量産へつなげる重要な転換点になりました。",
    "society": "環境性能と技術革新への関心が高まりました。",
    "spec1": "HV",
    "spec2": "環境技術",
    "spec3": "新時代",
    "image": "images/prius.jpg"
  },
  {
    "year": "1999",
    "era": "平成11年",
    "title": "ヴィッツ・ファンカーゴ・プラッツ",
    "visual": "VITZ",
    "car": "コンパクトカーのラインアップが広がりました。",
    "factory": "多車種生産への対応力を高めました。",
    "society": "暮らしにフィットする車が注目されました。",
    "spec1": "コンパクト",
    "spec2": "多車種",
    "spec3": "実用性",
    "image": "images/vit.jpg"
  },
  {
    "year": "2001",
    "era": "平成13年",
    "title": "工場生産累計2,000万台",
    "visual": "20M",
    "car": "カローラ ランクス・アレックスなど、日常の使いやすさを重視したモデルが生産されました。",
    "factory": "累計生産台数の節目を迎え、生産体制の強化が進みました。",
    "society": "品質と実用性の両立が求められました。",
    "spec1": "2,000万台",
    "spec2": "高効率",
    "spec3": "品質強化",
    "image": "images/corolla_runx.jpg"
  },
  {
    "year": "2007",
    "era": "平成19年",
    "title": "新第1ライン・オーリス時代",
    "visual": "AURIS",
    "car": "オーリスなど、グローバル視点の車づくりにつながる車種が生産されました。",
    "factory": "新ラインにより、生産能力と品質をさらに高めました。",
    "society": "世界市場での競争が強まりました。",
    "spec1": "新ライン",
    "spec2": "能力向上",
    "spec3": "品質向上",
    "image": "images/Au.jpg"
  },
  {
    "year": "2013",
    "era": "平成25年",
    "title": "第2ライン再開・SUV対応",
    "visual": "SUV",
    "car": "ハリアー、RAV4など、SUVラインへの対応が進みました。",
    "factory": "多様なニーズに対応する生産体制を強化しました。",
    "society": "SUVへの関心が高まりました。",
    "spec1": "SUV",
    "spec2": "第2ライン",
    "spec3": "多様化",
    "image": "images/harrier.jpg"
  },
  {
    "year": "2026",
    "era": "令和8年",
    "title": "高岡工場60周年",
    "visual": "60TH",
    "car": "60年の歩みを振り返り、次の時代の車づくりへつなげます。",
    "factory": "これまでの改善・品質・生産技術の積み重ねを未来へつなげます。",
    "society": "デジタル化や環境対応など、新しい価値づくりが求められています。",
    "spec1": "60周年",
    "spec2": "未来",
    "spec3": "DX",
    "image": "images/bzr4.jpg"
  }
];
const timelineFrame=document.getElementById("timelineFrame");
const timelineTrack=document.getElementById("timelineTrack");
const selectedYear=document.getElementById("selectedYear");
const selectedEra=document.getElementById("selectedEra");
const selectedTitle=document.getElementById("selectedTitle");
const mainPhoto=document.getElementById("mainPhoto");
const photoLink=document.getElementById("photoLink");
const visualTitle=document.getElementById("visualTitle");
const carIntro=document.getElementById("carIntro");
const factoryEvent=document.getElementById("factoryEvent");
const socialEvent=document.getElementById("socialEvent");
const spec1=document.getElementById("spec1");
const spec2=document.getElementById("spec2");
const spec3=document.getElementById("spec3");

function createInfoPhoto(textElement,idName){
  const photo=document.createElement("img");
  photo.id=idName;
  photo.style.width="60%";
  photo.style.maxHeight="140px";
  photo.style.objectFit="contain";
  photo.style.display="none";
  photo.style.margin="12px auto 0";
  photo.style.borderRadius="8px";
  if(textElement){
    textElement.insertAdjacentElement("afterend",photo);
  }
  return photo;
}

const carPhoto=createInfoPhoto(carIntro,"carPhoto");
const factoryPhoto=createInfoPhoto(factoryEvent,"factoryPhoto");
const societyPhoto=createInfoPhoto(socialEvent,"societyPhoto");

function updateInfoPhoto(photo,imagePath,altText){
  if(imagePath){
    photo.src=imagePath;
    photo.alt=altText;
    photo.style.display="block";
  }else{
    photo.removeAttribute("src");
    photo.alt="";
    photo.style.display="none";
  }
}
let offset=0;
let paused=false;
let activeIndex=0;
const speed=0.38;

function createNode(item,index){
  const button=document.createElement("button");
  button.className="year-node";
  button.type="button";
  button.dataset.index=index;
  button.innerHTML=`<span class="era">${item.era}</span><span class="wheel"><strong>${item.year}</strong></span><span class="node-photo"><img src="${item.image}" alt="${item.year}"></span>`;
  button.addEventListener("click",function(){
    activeIndex=index;
    showData(index);
    centerNode(index);
  });
  return button;
}

function buildTimeline(){
  timelineTrack.innerHTML="";
  for(let loop=0;loop<3;loop++){
    timelineData.forEach(function(item,index){
      timelineTrack.appendChild(createNode(item,index));
    });
  }
  showData(0);
}

function showData(index){
  const item=timelineData[index];
  selectedYear.textContent=item.year;
  selectedEra.textContent=item.era;
  selectedTitle.textContent=item.title;
  mainPhoto.src=item.image;
  mainPhoto.alt=item.year+" "+item.title;
  visualTitle.textContent=item.visual;
  carIntro.textContent=item.car;
  factoryEvent.textContent=item.factory;
  socialEvent.textContent=item.society;
  updateInfoPhoto(carPhoto,item.carImage,item.year+" 車紹介");
  updateInfoPhoto(factoryPhoto,item.factoryImage,item.year+" 工場の出来事");
  updateInfoPhoto(societyPhoto,item.societyImage,item.year+" 社会の出来事");
  spec1.textContent=item.spec1;
  spec2.textContent=item.spec2;
  spec3.textContent=item.spec3;
  if(photoLink){
    photoLink.href=item.image;
  }
  document.querySelectorAll(".year-node").forEach(function(node){
    node.classList.toggle("active",Number(node.dataset.index)===index);
  });
}

function centerNode(index){
  const nodes=Array.from(document.querySelectorAll(".year-node"));
  const target=nodes.find(function(node){return Number(node.dataset.index)===index;});
  if(!target)return;
  const frameCenter=timelineFrame.clientWidth/2;
  const nodeCenter=target.offsetLeft+target.offsetWidth/2;
  offset=frameCenter-nodeCenter;
  timelineTrack.style.transform="translateX("+offset+"px)";
}

function updateSelectedByCenter(){
  const frameRect=timelineFrame.getBoundingClientRect();
  const centerX=frameRect.left+frameRect.width/2;
  const nodes=Array.from(document.querySelectorAll(".year-node"));
  let nearestNode=null;
  let nearestDistance=Infinity;
  nodes.forEach(function(node){
    const rect=node.getBoundingClientRect();
    const nodeCenter=rect.left+rect.width/2;
    const distance=Math.abs(centerX-nodeCenter);
    if(distance<nearestDistance){
      nearestDistance=distance;
      nearestNode=node;
    }
  });
  if(!nearestNode)return;
  const newIndex=Number(nearestNode.dataset.index);
  if(newIndex!==activeIndex){
    activeIndex=newIndex;
    showData(activeIndex);
  }
}

function keepEndlessLoop(){
  const oneSetWidth=timelineTrack.scrollWidth/3;
  if(Math.abs(offset)>=oneSetWidth*2){offset+=oneSetWidth;}
  if(offset>0){offset-=oneSetWidth;}
}

function animate(){
  if(!paused){
    offset-=speed;
    keepEndlessLoop();
    timelineTrack.style.transform="translateX("+offset+"px)";
    updateSelectedByCenter();
  }
  requestAnimationFrame(animate);
}

timelineFrame.addEventListener("mouseenter",function(){paused=true;});
timelineFrame.addEventListener("mouseleave",function(){paused=false;});

photoLink.addEventListener("click",function(){
  const item=timelineData[activeIndex];
  alert(item.year+"年："+item.title);
});

buildTimeline();
centerNode(0);
animate();
